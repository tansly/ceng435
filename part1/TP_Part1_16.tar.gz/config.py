# Note that you should also set the message size in the Makefile of raspipe
msg_size = 8
